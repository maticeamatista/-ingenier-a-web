from django.urls import path
from .views import lista_noticias, detalle_noticia  #  Verifica que las funciones existen

urlpatterns = [
    path('', lista_noticias, name='lista_noticias'),
    path('<int:noticia_id>/', detalle_noticia, name='detalle_noticia'),
]
