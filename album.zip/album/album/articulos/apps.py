from django.apps import AppConfig

class ArticulosConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'articulos'  # Nota: aquí debe ser 'articulos', no 'apps.articulos'