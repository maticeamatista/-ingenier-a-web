const timers = [];
let intervalId;

const modal = document.getElementById("imageModal");
const modalImage = document.getElementById("modalImage");
const closeModal = document.querySelector(".close");

// Inicializar los temporizadores para cada tarjeta
document.querySelectorAll(".time-counter").forEach((_, index) => {
    timers[index] = 0;
});

function openModal(imageUrl) {
    modal.style.display = "block";
    modalImage.src = imageUrl;
}

function closeModalHandler() {
    modal.style.display = "none";
}

closeModal.addEventListener("click", closeModalHandler);

window.addEventListener("click", (event) => {
    if (event.target === modal) {
        closeModalHandler();
    }
});

function updateTimers() {
    document.querySelectorAll(".time-counter").forEach((counter, index) => {
        timers[index]++;
        counter.textContent = `${timers[index]} mins`;
    });
}

intervalId = setInterval(updateTimers, 60000);

function changeImage(event, imageElement, viewButton, timerElement, index) {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            const newImageUrl = e.target.result;
            imageElement.src = newImageUrl;
            viewButton.setAttribute("data-image", newImageUrl);
            timers[index] = 0;
            timerElement.textContent = "0 mins";
        };
        reader.readAsDataURL(file);
    }
}

// Manejar el clic en los botones "View"
document.querySelectorAll(".view-btn").forEach((button) => {
    button.addEventListener("click", (event) => {
        const imageUrl = event.target.getAttribute("data-image");
        openModal(imageUrl);
    });
});

// Manejar los inputs de archivo para cambiar imágenes
document.querySelectorAll(".file-input").forEach((input, index) => {
    const imageElement = document.querySelectorAll(".card-image")[index];
    const viewButton = document.querySelectorAll(".view-btn")[index];
    const timerElement = document.querySelectorAll(".time-counter")[index];

    input.addEventListener("change", (event) => {
        changeImage(event, imageElement, viewButton, timerElement, index);
    });
});