from django.shortcuts import render, get_object_or_404
from .models import Noticia

def listado_noticias(request):
    noticias = Noticia.objects.filter(publicada=True)
    return render(request, 'articulos/listado_noticias.html', {'noticias': noticias})

def detalle_noticia(request, slug):
    noticia = get_object_or_404(Noticia, slug=slug, publicada=True)
    return render(request, 'articulos/detalle_noticia.html', {'noticia': noticia})