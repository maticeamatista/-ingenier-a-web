from django.db import models
from django.utils.text import slugify

class Noticia(models.Model):
    titulo = models.CharField(max_length=200)
    slug = models.SlugField(max_length=200, unique=True, blank=True)
    fecha_publicacion = models.DateTimeField(auto_now_add=True)
    resumen = models.TextField()
    detalle = models.TextField()
    foto = models.ImageField(upload_to='noticias/', null=True, blank=True)
    publicada = models.BooleanField(default=True)

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.titulo)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.titulo

    class Meta:
        ordering = ['-fecha_publicacion']