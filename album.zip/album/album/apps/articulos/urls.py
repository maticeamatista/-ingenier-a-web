from django.urls import path
from . import views

urlpatterns = [
    path('', views.listado_noticias, name='listado_noticias'),
    path('<slug:slug>/', views.detalle_noticia, name='detalle_noticia'),
]