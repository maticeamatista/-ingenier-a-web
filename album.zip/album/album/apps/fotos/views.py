from django.shortcuts import render, redirect
from .models import Foto
from django.contrib import messages

def listado_fotos(request):
    fotos = Foto.objects.filter(publish=True)
    return render(request, "fotos/listado.html", {"fotos": fotos})

def upload_foto(request):
    if request.method == 'POST':
        nombre = request.POST.get('nombre')
        descripcion = request.POST.get('descripcion')
        imageurl = request.FILES.get('imageurl')
        publish = 'publish' in request.POST

        foto = Foto(
            nombre=nombre,
            descripcion=descripcion,
            imageurl=imageurl,
            publish=publish
        )
        foto.save()
        messages.success(request, 'Foto subida exitosamente.')
        return redirect('listado_fotos')
    return render(request, 'fotos/upload.html')

def eliminar_foto(request, foto_id):
    if request.method == 'POST':
        try:
            foto = Foto.objects.get(id=foto_id)
            foto.delete()
            messages.success(request, 'Foto eliminada exitosamente.')
        except Foto.DoesNotExist:
            messages.error(request, 'La foto no existe.')
        return redirect('listado_fotos')
    return redirect('listado_fotos')