from django.shortcuts import render
from .models import Mifoto

def listado_fotos(request):
    fotos = Mifoto.objects.filter(publish=True)
    return render(request, "fotos/listado.html", {"fotos": fotos})