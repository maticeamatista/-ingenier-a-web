from django.urls import path
from . import views

urlpatterns = [
    path('', views.listado_fotos, name='listado_fotos'),
    path('upload/', views.upload_foto, name='upload_foto'),
    path('eliminar/<int:foto_id>/', views.eliminar_foto, name='eliminar_foto'),
    path('', views.listado_fotos, name='listado_fotos'),
]