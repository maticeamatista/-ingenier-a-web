from django.db import models
from PIL import Image

class Mifoto(models.Model):
    nombre = models.CharField(max_length=255)
    descripcion = models.TextField(default="Sin descripción")
    imageurl = models.ImageField(upload_to='fotos/')
    publish = models.BooleanField(default=True)
    fecha = models.DateTimeField(auto_now_add=True)  # Asegúrate de que esto esté aquí

    def __str__(self):
        return self.nombre

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        if self.imageurl:
            img = Image.open(self.imageurl.path)
            if img.height > 800 or img.width > 800:
                output_size = (800, 800)
                img.thumbnail(output_size)
                img.save(self.imageurl.path)