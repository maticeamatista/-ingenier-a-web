from django import forms
from .models import Mifoto

class MifotoForm(forms.ModelForm):
    class Meta:
        model = Mifoto
        fields = ['nombre', 'descripcion', 'imageurl', 'publish']
