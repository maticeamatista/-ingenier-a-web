from django.contrib import admin

# Register your models here.
from .models import Mifoto 

admin.site.register(Mifoto)
