from django.shortcuts import render
from apps.fotos.models import Mifoto
from articulos.models import Noticia

def inicio(request):
    fotos = Mifoto.objects.all()
    noticias = Noticia.objects.all()
    return render(request, "pages/index.html", {"fotos": fotos, "noticias": noticias})