from django.shortcuts import render
from apps.articulos.models import Noticia
from apps.fotos.models import Foto

def inicio(request):
    fotos = Foto.objects.filter(publicada=True)
    noticias = Noticia.objects.filter(publicada=True)
    return render(request, 'pages/index.html', {'fotos': fotos, 'noticias': noticias})